#include "vh_io_hal.h"
#include "led.h"


#define DELAY		0x10000

void vh_LedInit(void)
{
}


void vh_LedSet(unsigned char data)
{
}

void vh_LedOn(unsigned char data)
{
}

void vh_LedOff(unsigned char data)
{
}



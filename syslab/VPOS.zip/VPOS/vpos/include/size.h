
#ifndef _VPOS_SIZE_H_
#define _VPOS_SIZE_H_

#define vh_thread_stack_size    1024
#define vh_heap_size	1000000

#endif // _VPOS_SIZE_H_

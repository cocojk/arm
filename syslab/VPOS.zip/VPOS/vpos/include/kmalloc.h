#ifndef _VPOS_KMALLOC_H_
#define _VPOS_KMALLOC_H_

void* vk_malloc(unsigned nbytes);
void vk_free(void* ap);

#endif // _VPOS_kMALLOC_H_

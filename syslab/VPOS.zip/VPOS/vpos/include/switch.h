
#ifndef QURIX_SWITCH_H
#define QURIX_SWITCH_H

void switch_init(void);
int switch_handler(void);

#endif

#ifndef _VPOS_HWI_HANDLER_H_
#define _VPOS_HWI_HANDLER_H_

void vh_hwi_classifier(void);
void vh_interrupt_mask(int mask_irq_number);
void vh_interrupt_unmask(int unmask_irq_number);

#endif //_VPOS_HWI_HANDLER_H_








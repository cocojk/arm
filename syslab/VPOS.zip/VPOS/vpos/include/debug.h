void vk_bkpt_exception_handler(void);
void vk_bkpt_set(unsigned int control, unsigned int addr);

unsigned char vr_miss_break;
